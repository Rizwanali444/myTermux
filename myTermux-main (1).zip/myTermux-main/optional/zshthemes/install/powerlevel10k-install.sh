#!/usr/bin/env bash

git clone --depth=1 https://github.com/romkatv/powerlevel10k.git ~/.oh-my-zsh/custom/themes/powerlevel10k

echo -e "run 'chzsh' to change theme"
